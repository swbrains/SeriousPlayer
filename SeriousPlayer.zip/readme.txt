SeriousPlayer

A Windows application that creates a dedicated browser window for the player.siriusxm.com website.

SiriusXM discontinued their native Windows player app. They now direct customers to use their browser
to log into their account at the SiriusXM website in order to listen to SXM on their PC. The problem 
this presents is that using your browser for other purposes may lead to closing your browser accidentally 
when you are done surfing, leading to the end of your listening session and forcing you to re-open your 
browser and navigate back to rthe SXM website.

This is a simple Windows application that creates a browser within a dedicated Windows application and 
navigates to the player.siriusxm.com website. This allows you to use (and close) your browser normally 
for normal website activity without having to worry about accidentally terminating your SXM listening 
session.

The application is simple -- It loads the SXM website. It does not have any configuraiton settings. Simply 
unpack the archive into it's own directory. It must have the WebView2Loader.dll from Microsoft in the same 
directory as the program executable.

This application is provided as freeware, with no warranty for any purpose other than it worked for me. 
I wrote it to allow me to listen to SirusXM on my PC like I did when the native Windows app was available. 
I am making this application available to the public in case it should be of use to someone else who is 
annoyed by the loss of a native Windows application for listening to SiriusXM.